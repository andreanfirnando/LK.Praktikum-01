const int buttonPin = 2;
const int ledPin = 4;

int buttonState = 0;
int lastButtonState = LOW;
bool ledState = false;

void setup() {
  Serial.begin(115200);

  pinMode(buttonPin, INPUT);
  pinMode(ledPin, OUTPUT);

  digitalWrite(ledPin, LOW);
  Serial.println("Sistem ESP32 Siap! Status Awal: LED MATI");
}

void loop() {
  buttonState = digitalRead(buttonPin);

  if (buttonState == HIGH && lastButtonState == LOW) {

    ledState = !ledState;

    if (ledState == true) {
      digitalWrite(ledPin, HIGH);
      Serial.println("Tombol ditekan 1x -> LED MENYALA (Terkunci ON)");
    } else {
      digitalWrite(ledPin, LOW);
      Serial.println("Tombol ditekan 1x -> LED MATI (Terkunci OFF)");
    }

    delay(200);
  }

  lastButtonState = buttonState;
}